package com.example.recyclerview5tob

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configuramos el RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerPersonas)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Lista de datos de alumnos
        val data = ArrayList<Alumno>()

        // Añadimos un alumno de ejemplo
        data.add(
            Alumno(
                "Karen González",
                "20195579",
                "kvelazco4@ucol.mx",
                "https://example.com/karen_profile.jpg"  // URL de ejemplo para la imagen
            )
        )

        // Configuramos el adaptador del RecyclerView
        val adapter = AlumnoAdapter(data)
        recyclerView.adapter = adapter
    }
}


