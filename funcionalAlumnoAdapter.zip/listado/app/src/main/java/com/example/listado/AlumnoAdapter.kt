package com.example.listado

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class AlumnoAdapter(
    private val context: Context,
    private val listAlumnos: List<Alumno>
) : RecyclerView.Adapter<AlumnoAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Infla la vista del ítem item_personas
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_personas, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val alumno = listAlumnos[position]
        // Asigna la imagen al ImageView usando Glide
        Glide.with(context).load(alumno.imagen).into(holder.imgFoto)
        // Asigna los valores a los TextViews
        holder.nombre.text = alumno.nombre
        holder.numCuenta.text = alumno.cuenta
    }

    override fun getItemCount(): Int {
        return listAlumnos.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgFoto: ImageView = itemView.findViewById(R.id.imgPersona)
        val nombre: TextView = itemView.findViewById(R.id.tvNombre)
        val numCuenta: TextView = itemView.findViewById(R.id.tvCuenta)
    }
}

